#' Optimum Distance Between Sense and Antisense Strands for PRO-Cap Data
#'
#' @param files      A size v vector of strings of filenames of the unzipped bed files to be processed
#' @param interval   A scalar indicating the distance to check for read pile ups - it will compute the negative and positive interval from each loci
#' @return           A list: readsPerDist: A size (interval*2 x 2) matrix with read pile ups at each distance within the interval
#'                            optimDist:  A scalar of the optimum distance value for the samples
#' @export

ComputeDistR <- function(files, interval=500) { 
  r=ComputeDist(files,interval)
  colnames(r$readsPerDist)=c("loci","AveSumOfLogProductofReads")
  pdf("ReadsPerDist.pdf")
  plot(r$readsPerDist)
  dev.off()
  return (r)
}