#include <Rcpp.h>
#include <queue>
#include <fstream>
#include <map>
using namespace Rcpp;
using namespace std;

void OpenFile(string fileName, vector<vector<unsigned int> > &parsedFile) {
  string s1;
  unsigned int chr, loci, junk, forward, reverse;
  vector <unsigned int> row;
  ifstream fs(fileName);
  getline(fs, s1);
  while (!getline(fs,s1).eof()){
    stringstream ss(s1);
    ss >> chr >> loci >> junk >> junk >> forward >> junk >> reverse;
    row.push_back(chr);
    row.push_back(loci);
    row.push_back(forward);
    row.push_back(reverse);
    parsedFile.push_back(row);
    row.clear();
  }
  fs.close();
}

void OptimDist(vector <vector <unsigned int> > &parsedFile, NumericMatrix& readsPerDist, const int interval){
  unsigned int i, currLoci, currReads, revReadsCurr, forReadsCurr, dist;
  int j;
  queue <unsigned int> revLoci, forLoci, revReads, forReads;
  for(i=0; i<parsedFile.size(); i++){
    currLoci=parsedFile[i][1];
    currReads=parsedFile[i][2];
    if (currReads>0){
      j=i;
      while (j>=0 && (currLoci-parsedFile[j][1])<interval){
        forLoci.push(parsedFile[j][1]);
        forReads.push(parsedFile[j][3]);
        j--;
      }
      j=i+1;
      while (j<parsedFile.size() && (parsedFile[j][1]-currLoci)<interval){
        revLoci.push(parsedFile[j][1]);
        revReads.push(parsedFile[j][3]);
        j++;
      }
      while(!revLoci.empty()){
        dist=currLoci-revLoci.front();
        revReadsCurr=revReads.front();
        if(revReadsCurr>0){
          readsPerDist(interval+dist,1)+=log(revReadsCurr*currReads+1);
        }
        revLoci.pop();
        revReads.pop();
      }
      while(!forLoci.empty()){
        dist=forLoci.front()-currLoci;
        forReadsCurr=forReads.front();
        if(forReadsCurr>0){
          readsPerDist(interval-dist,1)+=log(forReadsCurr*currReads+1);
        }
        forLoci.pop();
        forReads.pop();
      }
    }
  }
}

void ComputeMeans(NumericMatrix &readsPerDist, const unsigned int fileCount){
  unsigned int i, size=readsPerDist.nrow();
  for (i=0; i<size; i++){
    readsPerDist(i,1)/=fileCount;
  }
}

//' Optimum Distance Between Sense and Antisense Strands for PRO-Cap Data
//'
//' @param files      A size v vector of strings of filenames of the unzipped bed files to be processed
//' @param interval   A scalar indicating the distance to check for read pile ups - it will compute the negative and positive interval from each loci
//' @return           A list: readsPerDist: A size (interval*2 x 2) matrix with read pile ups at each distance within the interval
//'                            optimDist:  A scalar of the optimum distance value for the samples
// [[Rcpp::export]]
List ComputeDist(StringVector files, int interval){
  unsigned int fileCount=files.size();
  int i, optimDist;
  double maxValue=0;
  vector<vector<unsigned int> > parsedFile;
  NumericMatrix readsPerDist (interval*2,2);
  readsPerDist(0,0)=-interval;
  for (i=-interval+1; abs(i)<interval; i++){
    readsPerDist(i+interval,0)=i;
  }
  string file;
  for (i=0; i<fileCount; i++){
    file= as <std::string> (files(i));
    OpenFile(file,parsedFile);
    OptimDist(parsedFile,readsPerDist,interval);
    parsedFile.clear();
  }
  ComputeMeans(readsPerDist,fileCount);
  for (i=0; i<readsPerDist.nrow(); i++){
    if (readsPerDist(i,1)>maxValue){
      maxValue=readsPerDist(i,1);
      optimDist=i-interval;
    }
  }
  return List::create(Named("readsPerDist")=readsPerDist,
                      Named("optimDist")=optimDist);
}
