#include <Rcpp.h>
#include <fstream>
#include <queue>
#include <random>
using namespace Rcpp;
using namespace std;

void ClearQueue(queue <unsigned int>& full){ //swaps full queue with an empty queue and frees up the memory
  queue <unsigned int> empty;
  swap(full,empty);
}

void ClearQueueDouble(queue <double>& full){ //swaps full queue with an empty queue and frees up the memory
  queue <double> empty;
  swap(full,empty);
}

void OpenFile(string fileName, vector<vector<unsigned int> > &binnedFile, const unsigned int binSize) {
  string s1;
  unsigned int chr, loci, junk, forward, reverse, index=0;
  vector <unsigned int> row;
  ifstream fs(fileName);
  getline(fs, s1);
  while (!getline(fs,s1).eof()){
    stringstream ss(s1);
    ss >> chr >> loci >> junk >> junk >> forward >> junk >> reverse;
    loci=floor(loci/binSize);
    if (binnedFile.empty()){
      row.push_back(chr);
      row.push_back(loci);
      row.push_back(forward);
      row.push_back(reverse);
      binnedFile.push_back(row);
      row.clear();
    }else{
      if (binnedFile.back()[1]==loci && binnedFile.back().front()==chr){
        binnedFile[index][2]+=forward;
        binnedFile[index][3]+=reverse;
      }else{
        row.push_back(chr);
        row.push_back(loci);
        row.push_back(forward);
        row.push_back(reverse);
        binnedFile.push_back(row);
        row.clear();
        index++;
      }
    }
  }
  fs.close();
}

void SingleSample(vector<vector<unsigned int> > &binnedFile, vector< vector <double> > &singleSample, 
                  const unsigned int binDist){
  const unsigned int size=binnedFile.size();
  queue <unsigned int> revReadLoci, revReadCount;
  vector <double> row;
  unsigned int currentForReadPos, currentForChr, currentForReads, currentRevReads, currentDist, prevChr=0;
  for (unsigned int i=0; i<size; i++){
    currentForChr=binnedFile[i][0];
    currentForReadPos=binnedFile[i][1];
    currentRevReads=binnedFile[i][3];
    if (currentForChr!=prevChr){ //new chromosome - clear queue
      ClearQueue(revReadLoci);
      ClearQueue(revReadCount);
    }
    while (!revReadLoci.empty()){
      currentDist=currentForReadPos-revReadLoci.front();
      if (currentDist>2*binDist){ //reads too far apart - remove rev reads from queue
        revReadLoci.pop();
        revReadCount.pop();
      }else if(currentDist<2*binDist){ //reads too close together - break while loop
        break;
      }else if(currentDist==2*binDist){
        currentForReads=binnedFile[i][2];
        if (currentForReads>0){
        //if (currentForReads>0 && revReadCount.front()>0){
          row.push_back(currentForChr);
          row.push_back(currentForReadPos-binDist);
          row.push_back(log(currentForReads*revReadCount.front()+1));
          //row.push_back((currentForReads+revReadCount.front()));
          //row.push_back((currentForReads*revReadCount.front()));
          singleSample.push_back(row);
          row.clear();
        }
        revReadLoci.pop();
        revReadCount.pop();
        break;
      }
    }
    prevChr=currentForChr;
    if (currentRevReads>0){
      revReadLoci.push(currentForReadPos);
      revReadCount.push(currentRevReads);
    }
  }
}

void MergeSamples(vector <vector <double> > &singleSample, vector <vector <double> > &mergedSamples){
  unsigned int i=0, j=0, sizei=singleSample.size(), sizej=mergedSamples.size();
  double singleReads;
  vector <double> singleRow, mergedRow;
  while (i<sizei && j<sizej){
    if (singleRow.empty()){
      singleRow=singleSample[i];
    }
    if (mergedRow.empty()){
      mergedRow=mergedSamples[j];
    }
    if (singleRow.front()==mergedRow.front()){
      if (singleRow[1]<mergedRow[1]){
        singleRow.push_back(singleRow.back());
        singleRow.push_back(singleRow.back());
        singleRow.push_back(pow(singleRow.back(),2));
        singleRow.push_back(1);
        singleRow.push_back(99);
        mergedSamples.insert(mergedSamples.begin()+j,singleRow);
        singleRow.clear();
        i++;
        j++;
        sizej++;
      }else if (singleRow[1]>mergedRow[1]){
        mergedRow.clear();
        j++;
      }else{
        singleReads=singleRow.back();
        mergedSamples[j][2]+=singleReads;
        if (mergedSamples[j][3] < singleReads){
          mergedSamples[j][3]=singleReads;
        }
        if (mergedSamples[j][4] > singleReads){
          mergedSamples[j][4]=singleReads;
        }
        mergedSamples[j][5]+=singleReads*singleReads;
        mergedSamples[j][6]++;
        singleRow.clear();
        mergedRow.clear();
        j++;
        i++;
      }
    }
    else if(singleRow.front()>mergedRow.front()){
      mergedRow.clear();
      j++;
    }
    else if(singleRow.front()<mergedRow.front()){
      singleRow.push_back(singleRow.back());
      singleRow.push_back(singleRow.back());
      singleRow.push_back(pow(singleRow.back(),2));
      singleRow.push_back(1);
      singleRow.push_back(99);
      mergedSamples.insert(mergedSamples.begin()+j,singleRow);
      singleRow.clear();
      i++;
      j++;
      sizej++;
    }
  }
  while (i<sizei){
    singleRow=singleSample[i];
    singleRow.push_back(singleRow.back());
    singleRow.push_back(singleRow.back());
    singleRow.push_back(pow(singleRow.back(),2));
    singleRow.push_back(1);
    singleRow.push_back(99);
    mergedSamples.push_back(singleRow);
    singleRow.clear();
    i++;
  }
}

void ProcessMusSds(vector <vector <double> > &mergedSamples, const unsigned int fileCount){
  unsigned int i, size=mergedSamples.size();
  for (i=0;i<size;i++){
    mergedSamples[i][5]=pow((mergedSamples[i][5]-pow(mergedSamples[i][2],2)/fileCount)/(fileCount-1),.5);
    mergedSamples[i][2]/=fileCount;
  }
}

void KMeans3D(vector <vector <double> > &mergedSamples, unsigned int seed, const unsigned int k, const double tol, const unsigned int maxIter){
  unsigned int i, j, l, it, zeroCentroid, kcentroid, rseed, zerosCount, minCluster, minCluster2, minCluster3;
  double minDist, dist, centroidDist, prevDist=0, minCount=R_PosInf;
  vector <unsigned int> counts(k), pool(mergedSamples.size());
  vector <double> row, sums0(k), sums1(k), sums2(k); //indicates index in centroids
  vector <vector <double> > centroids;
  zerosCount=mergedSamples.back()[1]-mergedSamples.size();
  rseed=(seed==0) ? time(NULL) : seed;
  auto gen = std::default_random_engine(rseed);
  iota (pool.begin(),pool.end(),0);
  shuffle(pool.begin(),pool.end(),gen);
  for (j=0; j<k; j++){
    if (j<k-1){
      row.push_back(mergedSamples[pool[j]][2]);
      row.push_back(mergedSamples[pool[j]][3]);
      row.push_back(mergedSamples[pool[j]][5]);
      centroids.push_back(row);
      row.clear();
    }else if (j==(k-1)){
      row.push_back(0);
      row.push_back(0);
      row.push_back(0);
      centroids.push_back(row);
      row.clear();
    }
  }
  for(it=0; it<maxIter; it++){
    fill(sums0.begin(),sums0.end(),0);
    fill(sums1.begin(),sums1.end(),0);
    fill(sums2.begin(),sums2.end(),0);
    fill(counts.begin(),counts.end(),0);
    for (i=0;i<mergedSamples.size();i++){
      minDist=R_PosInf;
      for (j=0; j<k; j++){
        dist=pow(pow(centroids[j][0]-mergedSamples[i][2],2) 
                   + pow(centroids[j][1]-mergedSamples[i][3],2)
                   + pow(centroids[j][2]-mergedSamples[i][5],2),.5);
        if (dist<minDist){
          minDist=dist;
          mergedSamples[i].back()=j;
        }
      }
      kcentroid=mergedSamples[i].back();
      counts[kcentroid]++;
      sums0[kcentroid]+=mergedSamples[i][2];
      sums1[kcentroid]+=mergedSamples[i][3];
      sums2[kcentroid]+=mergedSamples[i][5];
    }
    minDist=R_PosInf;
    for (j=0;j<k;j++){
      dist=pow(pow(centroids[j][0],2) + pow(centroids[j][1],2) + pow(centroids[j][2],2),.5);
      if (dist<minDist){
        minDist=dist;
        zeroCentroid=j;
      }
    }
    counts[zeroCentroid]+=zerosCount;
    centroidDist=0;
    for (j=0; j<k; j++){
      sums0[j]/=counts[j];
      sums1[j]/=counts[j];
      sums2[j]/=counts[j];
      centroidDist+=pow(pow(centroids[j][0]-sums0[j],2) 
                          + pow(centroids[j][1]-sums1[j],2) 
                          + pow(centroids[j][2]-sums2[j],2),.5);
    }
    centroidDist/=k;
    centroids.clear();
    if(abs(prevDist-centroidDist)<tol){
      cout << "Kmeans Clustering Converged After: " << it << " Iterations" << endl;
      for (j=0; j<k; j++){
        if (counts[j]<minCount){
          minCount=counts[j];
          minCluster=j;
        }
      }
      break;
    }
    prevDist=centroidDist;
    for (j=0; j<k; j++){
      //if (counts[j]>=(0.001*mergedSamples.size())){ //groups > 5000
      if (counts[j]>=(0.00005*mergedSamples.size())){ 
        row.push_back(sums0[j]);
        row.push_back(sums1[j]);
        row.push_back(sums2[j]);
        centroids.push_back(row);
        row.clear();
      }else{
        shuffle(pool.begin(),pool.end(),gen);
        row.push_back(mergedSamples[pool[0]][2]);
        row.push_back(mergedSamples[pool[0]][3]);
        row.push_back(mergedSamples[pool[0]][5]);
        centroids.push_back(row);
        row.clear();
      }
    }
  }
  shuffle(pool.begin(),pool.end(),gen);
  j=0, i=0;
  while(j<k){
    if (mergedSamples[pool[i]].back()==minCluster){
      row.push_back(mergedSamples[pool[i]][2]);
      row.push_back(mergedSamples[pool[i]][3]);
      row.push_back(mergedSamples[pool[i]][5]);
      centroids.push_back(row);
      row.clear();
      j++;
    }
    i++;
  }
  for(it=0; it<maxIter; it++){
    fill(sums0.begin(),sums0.end(),0);
    fill(sums1.begin(),sums1.end(),0);
    fill(sums2.begin(),sums2.end(),0);
    fill(counts.begin(),counts.end(),0);
    for (i=0;i<mergedSamples.size();i++){
      if (mergedSamples[i].back()<k && mergedSamples[i].back()!=minCluster){
        continue;
      }
      minDist=R_PosInf;
      for (j=0; j<k; j++){
        dist=pow(pow(centroids[j][0]-mergedSamples[i][2],2) 
                   + pow(centroids[j][1]-mergedSamples[i][3],2)
                   + pow(centroids[j][2]-mergedSamples[i][5],2),.5);
          if (dist<minDist){
            minDist=dist; 
            mergedSamples[i].back() = (j==0) ? minCluster : (k+j-1);
          }
      }
      kcentroid= (mergedSamples[i].back()==minCluster) ? 0 : (mergedSamples[i].back()-k+1);
      counts[kcentroid]++;
      sums0[kcentroid]+=mergedSamples[i][2];
      sums1[kcentroid]+=mergedSamples[i][3];
      sums2[kcentroid]+=mergedSamples[i][5];
    }
    centroidDist=0;
    for (j=0; j<k; j++){
      sums0[j]/=counts[j];
      sums1[j]/=counts[j];
      sums2[j]/=counts[j];
      centroidDist+=pow(pow(centroids[j][0]-sums0[j],2) 
                          + pow(centroids[j][1]-sums1[j],2) 
                          + pow(centroids[j][2]-sums2[j],2),.5);
    }
    centroidDist/=k;
    if(abs(prevDist-centroidDist)<tol){
      cout << "Kmeans Clustering Converged (Again) After: " << it << " Iterations" << endl;
      for (j=0; j<k; j++){
        if (counts[j]<minCount){
          minCount=counts[j];
          minCluster2=j;
        }
      }
      minCount=R_PosInf;
      for (j=0; j<k; j++){
        if (counts[j]<minCount && j!=minCluster2){
          minCount=counts[j];
          minCluster3=(j==0) ? minCluster : (k+j-1);
        }
      }
      minCluster2 = (minCluster2==0) ? minCluster : (k+minCluster2-1);
      break;
    }
    prevDist=centroidDist;
    centroids.clear();
    for (j=0; j<k; j++){
      //if (counts[j]>=(0.001*mergedSamples.size())){ //groups > 5000
      if (counts[j]>=(0.00002*mergedSamples.size())){ 
        row.push_back(sums0[j]);
        row.push_back(sums1[j]);
        row.push_back(sums2[j]);
        centroids.push_back(row);
        row.clear();
      }else{
        shuffle(pool.begin(),pool.end(),gen);
        l=0;
        while (l<mergedSamples.size()){
          if (mergedSamples[pool[l]].back()<k && mergedSamples[pool[l]].back()!=minCluster){
            l++;
          }else{
            row.push_back(mergedSamples[pool[0]][2]);
            row.push_back(mergedSamples[pool[0]][3]);
            row.push_back(mergedSamples[pool[0]][5]);
            centroids.push_back(row);
            row.clear();
            break;
          }
        }
      }
    }
  }
  for (i=0; i<mergedSamples.size(); i++){
    mergedSamples[i].back() = (mergedSamples[i].back()==minCluster2) ? 2 : (mergedSamples[i].back()==minCluster3) ? 1 : 0;
  }
}

void GetDescriptives(vector <vector <double> > &mergedSamples, NumericMatrix &descriptives, const unsigned int k){
  unsigned int i, minCluster, midCluster, maxCluster, zeroCount, minCount=R_PosInf, maxCount=R_NegInf, size=mergedSamples.size();
  vector < vector <double> > sumsSqs(9, vector <double> (3));
  for (i=0; i<size; i++){
    descriptives(0,mergedSamples[i].back())++;
    sumsSqs[0][mergedSamples[i].back()]+=mergedSamples[i][2]; 
    sumsSqs[1][mergedSamples[i].back()]+=pow(mergedSamples[i][2],2);
    sumsSqs[2][mergedSamples[i].back()]+=mergedSamples[i][3]; 
    sumsSqs[3][mergedSamples[i].back()]+=pow(mergedSamples[i][3],2);
    sumsSqs[4][mergedSamples[i].back()]+=mergedSamples[i][5]; 
    sumsSqs[5][mergedSamples[i].back()]+=pow(mergedSamples[i][5],2);
    sumsSqs[6][mergedSamples[i].back()]+=mergedSamples[i][2]*mergedSamples[i][3];
    sumsSqs[7][mergedSamples[i].back()]+=mergedSamples[i][2]*mergedSamples[i][5];
    sumsSqs[8][mergedSamples[i].back()]+=mergedSamples[i][3]*mergedSamples[i][5];
  }
  zeroCount=mergedSamples.back()[1]-size;
  descriptives(0,0)+=zeroCount;
  for (i=0; i<3; i++){
    if (descriptives(0,i)>maxCount){
      maxCount=descriptives(0,i);
      maxCluster=i;
    }
    if (descriptives(0,i)<minCount){
      minCount=descriptives(0,i);
      minCluster=i;
    }
    descriptives(1,i)=sumsSqs[0][i]/descriptives(0,i);
    descriptives(2,i)=pow((sumsSqs[1][i]-pow(sumsSqs[0][i],2)/descriptives(0,i))/(descriptives(0,i)-1),.5);
    descriptives(3,i)=sumsSqs[2][i]/descriptives(0,i);
    descriptives(4,i)=pow((sumsSqs[3][i]-pow(sumsSqs[2][i],2)/descriptives(0,i))/(descriptives(0,i)-1),.5);
    descriptives(5,i)=sumsSqs[4][i]/descriptives(0,i);
    descriptives(6,i)=pow((sumsSqs[5][i]-pow(sumsSqs[4][i],2)/descriptives(0,i))/(descriptives(0,i)-1),.5);
    descriptives(7,i)=descriptives(1,i)+descriptives(3,i)+descriptives(5,i);
    descriptives(8,i)=descriptives(2,i)+descriptives(4,i)+descriptives(6,i)
                        +2*pow((sumsSqs[6][i]+sumsSqs[7][i] + sumsSqs[8][i]
                        -(sumsSqs[0][i]*sumsSqs[2][i]+sumsSqs[0][i]*sumsSqs[4][i]+sumsSqs[2][i]*sumsSqs[4][i])
                        /descriptives(0,i))/(descriptives(0,i)-1),.5);
  }
  for (i=0; i<3; i++){
    if (minCluster!=i && maxCluster!=i){
      midCluster=i;
    }
  }
}

void CalcEmissionsMat(vector <vector <double> > &mergedSamples, NumericMatrix &descriptives,
                 NumericMatrix &emissionsMat, NumericVector &zeros){
  unsigned int i, j, size=emissionsMat.nrow();
  for (i=0; i<size; i++){
    emissionsMat(i,0)=mergedSamples[i][1];
    for (j=0; j<(zeros.size()); j++){
      emissionsMat(i,j+1)=exp(-pow((mergedSamples[i][2]+mergedSamples[i][3]
                                +mergedSamples[i][5]-descriptives(7,j))
                               /descriptives(8,j),2)/2)/(pow(2*M_PI,.5)*descriptives(8,j));
    }
  }
  for (i=0; i<zeros.size(); i++){
    zeros(i)=exp(-pow(descriptives(7,i)/descriptives(8,i),2)/2)/(pow(2*M_PI,.5)*descriptives(8,i));
  }
}

void GetPiAndTrans(NumericVector &pi, NumericMatrix &trans){
  //trans and pi are not in log space after this function
  unsigned int states=trans.nrow();
  trans(0,0)=.999; //transition from j to i 
  trans(0,1)=.996;  //transition from state 1 to state 0 
  trans(0,2)=.99;
  trans(1,0)=.0005;
  trans(1,1)=.002;
  trans(1,2)=.005;
  trans(2,0)=.0005;
  trans(2,1)=.002;
  trans(2,2)=.005;
  for (unsigned int i=0; i<states; i++){
    for (unsigned int j=0; j<states; j++){
      pi(i)+=trans(i,j)/states;
    }
  }
}

void ViterbiPath(NumericMatrix &emissionsMat, IntegerMatrix &viterbiPath, 
                 NumericMatrix &trans, NumericVector &pi, NumericVector &zeros) {
  //all matrices enter in non log space but are calculated in log space
  unsigned int n = viterbiPath.nrow(), states=trans.nrow(), start=emissionsMat(0,0), obsIndex=1, incrIndex=0, vitLoci, obsLoci;
  vector <double> deltaPrev(states), deltaNew(states);
  vector <vector <unsigned int> > phi(states, vector <unsigned int> (n));
  double maxj=R_NegInf, v;
  for (unsigned int i=0; i<states; i++){
    deltaPrev[i]=log(pi(i)*emissionsMat(0,i+1)); //this is ok because we always start at nonzero read;
    zeros[i]=log(zeros[i]); //now zeros is in log space
  }
  viterbiPath(0,0)=emissionsMat(0,0);
  for (unsigned int t=1; t<n; ++t){
    viterbiPath(t,0)=start+t;
    vitLoci=start+t;
    obsLoci=emissionsMat(obsIndex,0);
    incrIndex=0;
    for (unsigned int i=0; i<states; ++i){
      maxj=R_NegInf;
      for (unsigned int j=0; j<states; ++j){
        v=deltaPrev[j]+log(trans(j,i));
        if (v>maxj){
          maxj=v;
          deltaNew[i]=v;
          phi[i][t]=j;
        }
      }
      if(vitLoci==obsLoci){
        deltaNew[i]+=log(emissionsMat(obsIndex,i+1));
        incrIndex=1;
      }else{
        deltaNew[i]+=zeros[i];
      }
      deltaPrev[i]=deltaNew[i];
    }
    if(incrIndex==1){
      obsIndex++;
    }
  }
  double max=R_NegInf;
  for (unsigned int i=0; i<states; i++){
    zeros[i]=exp(zeros[i]); //back to non log scale for forward backward
    if (deltaNew[i]>max){
      max=deltaNew[i];
    }
  }
  for (unsigned int j=n-1; j>0; --j){
    viterbiPath(j-1,1)=phi[viterbiPath(j,1)][j];
  }
}

void ForwardBackward(NumericMatrix &emissionsMat, NumericMatrix &condProb, NumericMatrix &trans, 
                     NumericVector &pi, NumericVector &zeros){
  int i, j, t, n=condProb.nrow(), states=pi.size(), start=emissionsMat(0,0), condLoci, obsLoci, obsIndex=1, incrIndex=0;
  double sum;
  vector <vector <double> > alpha(states,vector <double> (n)), beta(states, vector <double> (n));
  vector <double> scale(n);
  for (i=0; i<states; ++i){
    scale.front()+=pi[i]*emissionsMat(0,i+1);
  }
  for (i=0; i<states; ++i){
    alpha[i].front()=pi[i]*emissionsMat(0,i+1)/scale.front();
    beta[i].back()=1;
  }
  condProb(0,0)=emissionsMat(0,0);
  for (t=1; t<n; ++t){
    incrIndex=0;
    condProb(t,0)=t+start;
    condLoci=t+start;
    obsLoci=emissionsMat(obsIndex,0);
    for (i=0; i<states; ++i){
      for (j=0; j<states; ++j){
        scale[t]+=alpha[j][t-1]*trans(j,i);
      }
      if (condLoci==obsLoci){
        scale[t]*=emissionsMat(obsIndex,i+1);
      }else{
        scale[t]*=zeros[i];
      }
    }
    for (i=0; i<states; ++i){
      for (j=0; j<states; ++j){
        alpha[i][t]+=alpha[j][t-1]*trans(j,i);
      }
      if (condLoci==obsLoci){
        alpha[i][t]*=emissionsMat(obsIndex,i+1)/scale[t];
        incrIndex=1;
      }else{
        alpha[i][t]*=zeros[i]/scale[t];
      }
    }
    if (incrIndex==1){
      obsIndex++;
    }
  }
  obsIndex=emissionsMat.nrow()-1;
  for (t=n-2; t>=0; --t){
    incrIndex=0;
    condLoci=condProb(t+1,0);
    obsLoci=emissionsMat(obsIndex,0);
    for (i=0; i<states; ++i){
      for (j=0; j<states; ++j){
        if (condLoci==obsLoci){
          beta[i][t]+=beta[j][t+1]*trans(i,j)*emissionsMat(obsIndex,j+1);
          incrIndex=1;
        }else{
          beta[i][t]+=beta[j][t+1]*trans(i,j)*zeros[j];
        }
      }
      beta[i][t]/=scale[t+1];
    }
    if (incrIndex==1){
      obsIndex--;
    }
  }
  for (t=0; t<n; ++t){
    sum=0;
    for (i=0; i<states; ++i){
      sum+=alpha[i][t]*beta[i][t]; 
    }
    for (i=0; i<states; ++i){
      condProb(t,i+1)=(alpha[i][t]*beta[i][t])/sum; 
    }
  }
}

//' MultiSample HMM for Single Chromosome PRO-Cap Data
//'
//' @param binSize    A scalar indicating the number of basepairs in each bin
//' @param dist       A scalar indicating the distance between the possible peak and the forward reads 
//' @param filenames  A size v vector of strings of filenames of the unzipped bed files to be processed
//' @param seed       A scalar random seed value for k means clustering stochastic processes - default is to use time to set seed
//' @param tol        A scalar indicating tolerance to declare convergence during both iterations of k means clustering
//' @param maxIter    A scalar indicating maximum number of iterations within k means clustering algorithm
//' @return           A list: mergedSamples: A size (n x 8) matrix with read count descriptives at each nonzero loci for the combined samples
//'                            descriptives:  A size (3 x 9) matrix of descriptives for each cluster of loci and for the emissions matrix distributions
//'                            emissionsMat:  A size (n x 4) matrix containing probabilites determined by normal distribution of Z=ave+max+sd of read counts for each cluster
//'                            viterbiPath:   A size (m x 2) matrix of MLE states for HMM (contains all loci - not just nonzero loci)
//'                            condProb:      A size (m x 4) matrix of conditional probabilites at each loci from HMM
//[[Rcpp::export]]
List MultiSampleHMM(unsigned int binSize, unsigned int dist, StringVector files, unsigned int seed=0, 
                    const double tol=1e-5, const unsigned int maxIter=1e4){
  unsigned int i, j, size, fileCount=files.size(), k=3;
  unsigned int binDist=floor(dist/binSize);
  vector <double> row;
  vector<vector<unsigned int> > binnedFile;
  vector<vector<double> > mergedSamples, singleSample;
  NumericMatrix descriptives (9, 3);
  string file;
  for (i=0; i<fileCount; i++){
    file= as <std::string> (files(i));
    OpenFile(file,binnedFile,binSize);
    SingleSample(binnedFile,singleSample,binDist);
    binnedFile.clear();
    if (i>0){
      MergeSamples(singleSample,mergedSamples);
    }else{
      size=singleSample.size();
      for (j=0; j<size; j++){
        row=singleSample.front();
        row.push_back(row.back());
        row.push_back(row.back());
        row.push_back(pow(row.back(),2));
        row.push_back(1);
        row.push_back(99);
        mergedSamples.push_back(row);
        row.clear();
        singleSample.erase(singleSample.begin());
      }
    }
    singleSample.clear();
  }
  unsigned int totalReads=mergedSamples.back()[1]-mergedSamples.front()[1]+1;
  NumericVector pi(3), zeros(3);
  NumericMatrix emissionsMat(mergedSamples.size(), 4), condProb(totalReads, 4), trans(3, 3);
  IntegerMatrix viterbiPath(totalReads, 2);
  ProcessMusSds(mergedSamples,fileCount);
  KMeans3D(mergedSamples,seed,k,tol,maxIter);
  GetDescriptives(mergedSamples, descriptives, k);
  CalcEmissionsMat(mergedSamples, descriptives, emissionsMat, zeros);
  GetPiAndTrans(pi,trans);
  ViterbiPath(emissionsMat, viterbiPath, trans, pi, zeros);
  ForwardBackward(emissionsMat, condProb, trans, pi, zeros);
  return List::create(Named("mergedSamples") = mergedSamples,  
                      Named("descriptives")     = descriptives,
                      Named("emissionsMat")  = emissionsMat,
                      Named("viterbiPath") =viterbiPath,
                      Named("condProb")=condProb);
}

