#' MultiSample HMM for PRO-Cap Data
#'
#' @param binSize       A scalar indicating the number of basepairs in each bin
#' @param dist          A scalar indicating the distance between the possible peak and the forward reads 
#' @param filenames     A size v vector of strings of filenames of the unzipped bed files to be processed
#' @param seed          A scalar random seed value for k means clustering stochastic processes - default is to use time to set seed
#' @param tol           A scalar indicating tolerance to declare convergence during both iterations of k means clustering
#' @param maxIter       A scalar indicating maximum number of iterations within k means clustering algorithm
#' @return          A list: mergedSamples: A size (n x 8) matrix with read count descriptives at each nonzero loci for the combined samples
#'                          descriptives:  A size (3 x 9) matrix of descriptives for each cluster of loci and for the emissions matrix distributions
#'                          emissionsMat:  A size (n x 4) matrix containing probabilites determined by normal distribution of Z=ave+max+sd of read counts for each cluster
#'                          viterbiPath:   A size (m x 2) matrix of MLE states for HMM (contains all loci - not just nonzero loci)
#'                          condProb:      A size (m x 4) matrix of conditional probabilites at each loci from HMM
#' @export

MultiSampleHMMR <- function(binSize, dist, filenames, seed=0, tol=1e-5, maxIter=1e4) { 
  r=MultiSampleHMM(binSize,dist,files,seed,tol,maxIter)
  attributes(r$mergedSamples)=list(row.names=c(NA_integer_,length(r$mergedSamples[[1]])), class="data.frame", 
                                   names=c(1:length(r$mergedSamples)))
  r$mergedSamples=t(r$mergedSamples)
  colnames(r$mergedSamples)=c("chr","loci","ave","max","nonzeroMin","sd","nonzeroSampleCount","cluster")
  r$descriptives=t(r$descriptives)
  colnames(r$descriptives)=c("count","muAverage","muSD","maxAverage","maxSD","sdAverage","sdSD","sumAverage","sumSD")
  colnames(r$emissionsMat)=c("loci","noTFBSProb","variantTFBSProb","sharedTFBSProb")
  colnames(r$viterbiPath)=c("loci","MLEState")
  colnames(r$condProb)=c("loci","noTFBSProb","variantTFBSProb","sharedTFBSProb")
  return (r)
}